<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Portal - TransLogistics Global</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Trans<span>Logistics</span> Global</div>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="services.php">Services</a>
                <a href="index.php">Tracking</a>
                <a href="portal.php" class="active">Portal</a>
            </div>
        </nav>
    </header>

    <main>
        <section class="hero">
            <h1>Partner Portal</h1>
            <p>Secure access for logistics partners and authorized personnel.</p>
        </section>

        <section class="tracking-panel" style="max-width: 500px; margin: 0 auto;">
            <form action="#" method="POST" style="display: flex; flex-direction: column; gap: 15px;">
                <div class="form-group">
                    <label for="username">Username / ID</label>
                    <input type="text" id="username" name="username" style="width: 100%; padding: 12px; background: #333; border: 1px solid #555; color: white; border-radius: 5px;">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" style="width: 100%; padding: 12px; background: #333; border: 1px solid #555; color: white; border-radius: 5px;">
                </div>
                <button type="button" class="btn" onclick="alert('Access Denied: Please contact IT support (or try uploading a manifest on the Home page).')">Login</button>
                <p style="text-align: center; color: #888; font-size: 0.8em; margin-top: 10px;">Restricted Area. All activity is monitored.</p>
            </form>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; 2024 TransLogistics Global. All rights reserved.</p>
    </footer>
</body>
</html>
