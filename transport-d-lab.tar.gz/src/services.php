<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - TransLogistics Global</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Trans<span>Logistics</span> Global</div>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="services.php" class="active">Services</a>
                <a href="index.php">Tracking</a>
                <a href="portal.php">Portal</a>
            </div>
        </nav>
    </header>

    <main>
        <section class="hero">
            <h1>Our Logistic Services</h1>
            <p>Comprehensive solutions for your global supply chain needs.</p>
        </section>

        <section class="info-section" style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 40px;">
            <div style="background: #2d2d2d; padding: 30px; border-radius: 8px;">
                <h2 style="color: var(--primary-color);">Ocean Freight</h2>
                <p>Reliable ocean transport with established partnerships across all major trade lanes. We offer FCL and LCL shipments with real-time tracking integration.</p>
            </div>
            <div style="background: #2d2d2d; padding: 30px; border-radius: 8px;">
                <h2 style="color: var(--primary-color);">Air Freight</h2>
                <p>When time is critical, our air freight services ensure your cargo reaches its destination. From express charter to consolidation services.</p>
            </div>
            <div style="background: #2d2d2d; padding: 30px; border-radius: 8px;">
                <h2 style="color: var(--primary-color);">Overland Transport</h2>
                <p>Our fleet of 5000+ trailers and trucks provides seamless door-to-door delivery across the continent.</p>
            </div>
            <div style="background: #2d2d2d; padding: 30px; border-radius: 8px;">
                <h2 style="color: var(--primary-color);">Warehousing</h2>
                <p>State-of-the-art warehousing facilities with inventory management systems securely accessible via our Client Portal.</p>
            </div>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; 2024 TransLogistics Global. All rights reserved.</p>
    </footer>
</body>
</html>
