<?php
// Enable error reporting for debugging (simulating an environment where errors might leak info)
error_reporting(0);
libxml_disable_entity_loader(false); // EXPLICITLY ALLOW ENTITY LOADING FOR LOCAL LAB

$result = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $xmlData = trim($_POST['xml']);

    if (!empty($xmlData)) {
        $dom = new DOMDocument();
        
        // VULNERABILITY: LIBXML_NOENT enables the substitution of entities
        // LIBXML_DTDLOAD enables loading of external DTDs
        if ($dom->loadXML($xmlData, LIBXML_NOENT | LIBXML_DTDLOAD)) {
            
            $simpleXml = simplexml_import_dom($dom);
            
            $result .= "<h2>Tracking Details Found</h2>";
            $result .= "<div class='shipment-info'>";
            
            // Iterate through children to show reflected data
            foreach ($simpleXml->children() as $key => $value) {
                // If the XML structure is nested, just show top level for simplicity in this lab
                $result .= "<p><strong>".ucfirst($key).":</strong> " . htmlspecialchars($value) . "</p>"; 
            }
            
            $result .= "</div>";
            $result .= "<p style='color: #4CAF50; margin-top: 10px;'>✓ System synchronized.</p>";
            
        } else {
            $result = "<p style='color: #ef476f;'>Error: Invalid XML Format. Please verify your manifest.</p>";
        }
    } else {
        $result = "<p style='color: #ffd166;'>Warning: No data received.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tracking Results - TransLogistics Global</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Trans<span>Logistics</span> Global</div>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="services.php">Services</a>
                <a href="index.php">Tracking</a>
                <a href="portal.php">Portal</a>
            </div>
        </nav>
    </header>

    <main>
        <section class="hero">
            <h1>Shipment Status</h1>
        </section>

        <section class="tracking-panel">
            <div class="result-box">
                <?php echo $result; ?>
            </div>
            
            <div style="margin-top: 30px; text-align: center;">
                <a href="index.php" class="btn">Track Another Shipment</a>
            </div>
        </section>
    </main>
    
    <footer class="footer">
        <p>&copy; 2024 TransLogistics Global. All rights reserved.</p>
    </footer>
</body>
</html>
