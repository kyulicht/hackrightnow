<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TransLogistics Global - Shipment Tracking</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Trans<span>Logistics</span> Global</div>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="services.php">Services</a>
                <a href="index.php">Tracking</a>
                <a href="portal.php">Portal</a>
            </div>
        </nav>
    </header>

    <main>
        <section class="hero">
            <h1>Global Shipment Tracking</h1>
            <p>Real-time visibility for your supply chain. Upload your shipment manifest XML to track status.</p>
        </section>

        <section class="tracking-panel">
            <form action="tracker.php" method="POST">
                <div class="form-group">
                    <label for="manifest">Upload Manifest / Shipment Data (XML)</label>
                    <textarea name="xml" id="manifest" placeholder="&lt;?xml version='1.0'?&gt;&lt;shipment&gt;&lt;id&gt;TRK-992100&lt;/id&gt;&lt;priority&gt;High&lt;/priority&gt;&lt;/shipment&gt;"><?php 
                        if(isset($_GET['sample'])) {
                            echo "<?xml version='1.0' encoding='UTF-8'?>\n<root>\n  <shipment>\n    <id>TRK-1092</id>\n    <origin>New York</origin>\n    <destination>London</destination>\n    <status>In Transit</status>\n  </shipment>\n</root>";
                        }
                    ?></textarea>
                </div>
                <button type="submit" class="btn">Track Shipment</button>
                <a href="?sample=true" style="margin-left: 15px; color: #aaa; text-decoration: none; font-size: 0.9em;">Load Sample Data</a>
            </form>
        </section>

        <section class="info-section" style="margin-top: 50px; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
            <div style="background: #2d2d2d; padding: 20px; border-radius: 8px;">
                <h3 style="color: var(--accent-color);">Live Tracking</h3>
                <p>GPS integration with our fleet of over 5000 vehicles worldwide.</p>
            </div>
            <div style="background: #2d2d2d; padding: 20px; border-radius: 8px;">
                <h3 style="color: var(--accent-color);">Secure & Reliable</h3>
                <p>All data processed via our XML-RPC gateway for maximum interoperability.</p>
            </div>
            <div style="background: #2d2d2d; padding: 20px; border-radius: 8px;">
                <h3 style="color: var(--accent-color);">24/7 Support</h3>
                <p>Our logistics experts are available around the clock.</p>
            </div>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; 2024 TransLogistics Global. All rights reserved.</p>
    </footer>
</body>
</html>
