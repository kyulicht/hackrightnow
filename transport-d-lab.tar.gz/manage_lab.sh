#!/bin/bash

# Definition of colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

function show_banner {
    echo -e "${BLUE}"
    echo "  _______                     __               _     _   _          "
    echo " |__   __|                   / /              (_)   | | (_)         "
    echo "    | |_ __ __ _ _ __  ___  / /_     ___  __ _ _ ___| |_ _  ___ ___ "
    echo "    | | '__/ _\` | '_ \/ __|/ /_ \   / _ \/ _\` | / __| __| |/ __/ __|"
    echo "    | | | | (_| | | | \__ \ / /\ \ |  __/ (_| | \__ \ |_| | (__\__ \\"
    echo "    |_|_|  \__,_|_| |_|___//_/  \_\ \___|\__, |_|___/\__|_|\___|___/"
    echo "                                          __/ |                     "
    echo "                                         |___/                      "
    echo "     Vulnerability Lab v1.0"
    echo -e "${NC}"
}

CONTAINER_NAME="transport-xxe-lab"
IMAGE_NAME="transport-xxe-lab-image"

function start_lab {
    echo -e "${GREEN}[+] Starting Transport XXE Lab...${NC}"
    if command -v docker-compose &> /dev/null; then
        docker-compose up -d --build
    elif docker compose version &> /dev/null; then
        docker compose up -d --build
    else
        echo -e "${BLUE}[*] docker-compose not found, using raw docker commands...${NC}"
        docker build -t $IMAGE_NAME .
        docker run -d -p 8085:80 --privileged --name $CONTAINER_NAME $IMAGE_NAME
    fi
    echo -e "${GREEN}[+] Lab is running!${NC}"
    echo -e "${BLUE}[+] Access the app at: http://localhost:8085${NC}"
}

function stop_lab {
    echo -e "${RED}[-] Stopping Lab...${NC}"
    if command -v docker-compose &> /dev/null; then
        docker-compose down
    elif docker compose version &> /dev/null; then
        docker compose down
    else
        echo -e "${BLUE}[*] Stopping container $CONTAINER_NAME...${NC}"
        docker stop $CONTAINER_NAME 2>/dev/null
        docker rm $CONTAINER_NAME 2>/dev/null
    fi
    echo -e "${RED}[-] Lab stopped.${NC}"
}

function restart_lab {
    stop_lab
    start_lab
}

function status_lab {
    if command -v docker-compose &> /dev/null; then
        docker-compose ps
    elif docker compose version &> /dev/null; then
        docker compose ps
    else
        docker ps | grep $CONTAINER_NAME
    fi
}

# Check argument
case "$1" in
    start)
        show_banner
        start_lab
        ;;
    stop)
        show_banner
        stop_lab
        ;;
    restart)
        show_banner
        restart_lab
        ;;
    status)
        show_banner
        status_lab
        ;;
    *)
        show_banner
        echo "Usage: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac
