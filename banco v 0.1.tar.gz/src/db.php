<?php
$servername = "db";
$username = "user";
$password = "password";
$dbname = "bank_db";

// Create connection
// Enable error reporting for mysqli to throw exceptions
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
} catch (mysqli_sql_exception $e) {
    // Check if it's a "Name or service not known" error (likely local execution)
    if (strpos($e->getMessage(), 'php_network_getaddresses') !== false) {
        die("<strong>Connection failed:</strong> Database host '$servername' not found.<br>" .
            "<em>Hint: Are you running this script locally? It is designed to run inside the Docker container.</em><br>" .
            "<em>Run ./manage_lab.sh option 1 to start the lab.</em>");
    }
    die("Connection failed: " . $e->getMessage());
}
?>
