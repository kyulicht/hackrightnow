<?php
session_start();
include 'db.php';

if (!isset($_SESSION['userid'])) {
    header("Location: index.php");
    exit();
}

$user_role = $_SESSION['role'];
$user_name = $_SESSION['username'];
$user_id = $_SESSION['userid'];

// Fetch current user details
$stmt = $conn->prepare("SELECT account_balance, notes FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user_data = $result->fetch_assoc();

// If admin, fetch ALL users
$all_users = [];
if ($user_role === 'admin') {
    $admin_sql = "SELECT * FROM users";
    $admin_result = $conn->query($admin_sql);
    while($row = $admin_result->fetch_assoc()) {
        $all_users[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeoBank - Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container <?php echo ($user_role === 'admin') ? 'wide' : ''; ?>">
        <div class="navbar">
            <div class="logo">NeoBank</div>
            <div style="display: flex; align-items: center; gap: 1rem;">
                <span>Hello, <b><?php echo htmlspecialchars($user_name); ?></b></span>
                <a href="index.php" class="logout-btn" style="text-decoration: none; border-radius: 4px; font-size: 0.8rem;">Logout</a>
            </div>
        </div>

        <h2>Account Overview</h2>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem;">
            <div>
                <label>Balance</label>
                <div class="balance">$<?php echo number_format($user_data['account_balance'], 2); ?></div>
            </div>
            <div>
                <label>Account Type</label>
                <div style="font-size: 1.25rem;"><?php echo ucfirst($user_role); ?></div>
            </div>
        </div>

        <?php if ($user_role === 'admin'): ?>
            <div style="margin-top: 3rem; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 2rem;">
                <h2 style="color: var(--error-color);">⚠ ADMIN PANEL - CONFIDENTIAL</h2>
                <p>Access Level: <span class="sensitive">UNRESTRICTED</span></p>
                
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Password (Encrypted)</th>
                            <th>Balance</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($all_users as $u): ?>
                        <tr>
                            <td><?php echo $u['id']; ?></td>
                            <td><?php echo htmlspecialchars($u['username']); ?></td>
                            <td class="sensitive"><?php echo htmlspecialchars($u['password']); ?></td>
                            <td>$<?php echo number_format($u['account_balance'], 2); ?></td>
                            <td><?php echo htmlspecialchars($u['notes']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="background: rgba(255,255,255,0.05); padding: 1.5rem; border-radius: 8px;">
                <label>Personal Notes</label>
                <p><?php echo htmlspecialchars($user_data['notes']); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
