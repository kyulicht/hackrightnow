CREATE DATABASE IF NOT EXISTS bank_db;
USE bank_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    account_balance DECIMAL(15, 2) DEFAULT 0.00,
    role ENUM('user', 'admin') DEFAULT 'user',
    notes TEXT
);

INSERT INTO users (username, password, account_balance, role, notes) VALUES
('admin', 'SuperSecretAdminPass123!', 9999999.00, 'admin', 'FLAG{NndkKDOKF52E24fg5e454G45E4FD22E2E5RF7dddd8ef45hackrightnowFD2}'),
('alice', 'alice123', 5250.50, 'user', 'Regular user account'),
('bob', 'bob456', 150.75, 'user', 'Savings account for vacation'),
('charlie', 'charlie789', 500000.00, 'user', 'Business account');
