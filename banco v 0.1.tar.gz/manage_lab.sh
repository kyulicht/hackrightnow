#!/bin/bash

# Bank SQLi Lab Management Script

BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Determine docker-compose command
if [ -f "./utils/docker-compose" ]; then
    DOCKER_COMPOSE="./utils/docker-compose"
elif command -v docker-compose &> /dev/null; then
    DOCKER_COMPOSE="docker-compose"
elif docker compose version &> /dev/null; then
    DOCKER_COMPOSE="docker compose"
else
    echo -e "${RED}[!] Error: docker-compose not found. Please install it or run this script from the project root.${NC}"
    exit 1
fi

function show_menu {
    echo -e "${BLUE}==============================${NC}"
    echo -e "${BLUE}   Bank SQLi Lab Manager      ${NC}"
    echo -e "${BLUE}==============================${NC}"
    echo "1. Start Lab"
    echo "2. Stop Lab"
    echo "3. Restart Lab"
    echo "4. View Logs"
    echo "5. Exit"
    echo -n "Enter your choice: "
}

function start_lab {
    echo -e "${GREEN}[*] Starting Bank SQLi Lab...${NC}"
    # Check if docker is running
    if ! docker info > /dev/null 2>&1; then
        echo -e "${RED}[!] Docker is not running. Please start Docker first.${NC}"
        return
    fi
    $DOCKER_COMPOSE up --build -d
    echo -e "${GREEN}[*] Lab started successfully!${NC}"
    echo -e "${GREEN}[*] Access the bank at: http://localhost:8080${NC}"
}

function stop_lab {
    echo -e "${RED}[*] Stopping Bank SQLi Lab...${NC}"
    $DOCKER_COMPOSE down
    echo -e "${RED}[*] Lab stopped.${NC}"
}

function restart_lab {
    stop_lab
    start_lab
}

function view_logs {
    echo -e "${BLUE}[*] Tailing logs (Ctrl+C to exit)...${NC}"
    $DOCKER_COMPOSE logs -f
}

while true; do
    show_menu
    read choice
    case $choice in
        1) start_lab ;;
        2) stop_lab ;;
        3) restart_lab ;;
        4) view_logs ;;
        5) echo "Exiting..."; exit 0 ;;
        *) echo -e "${RED}Invalid choice. Please try again.${NC}" ;;
    esac
    echo ""
done
