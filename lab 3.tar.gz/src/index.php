<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Network Status Tool</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            width: 400px;
            border-top: 4px solid #0056b3;
        }
        h1 {
            color: #0056b3;
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }
        h2 {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 2rem;
            font-weight: normal;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }
        .input-group {
            margin-bottom: 1.5rem;
        }
        input[type="text"] {
            width: 100%;
            padding: 0.6rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box; /* Ensures padding doesn't affect width */
        }
        button {
            width: 100%;
            background-color: #0056b3;
            color: white;
            border: none;
            padding: 0.8rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.2s;
        }
        button:hover {
            background-color: #004494;
        }
        .output {
            margin-top: 2rem;
            background-color: #2d2d2d;
            color: #00ff00;
            padding: 1rem;
            border-radius: 4px;
            font-family: 'Courier New', Courier, monospace;
            white-space: pre-wrap;
            font-size: 0.9rem;
            max-height: 300px;
            overflow-y: auto;
        }
        .footer {
            margin-top: 2rem;
            text-align: center;
            font-size: 0.8rem;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>SysAdmin Tools</h1>
        <h2>Server Connectivity Check</h2>
        <form method="POST">
            <div class="input-group">
                <label for="ip">Target IP / Hostname</label>
                <input type="text" id="ip" name="ip" placeholder="e.g., 8.8.8.8" required>
            </div>
            <button type="submit">Ping Host</button>
        </form>

        <?php
        if (isset($_POST['ip'])) {
            $target = $_POST['ip'];
            echo '<div class="output">';
            echo "<strong>Command Output:</strong>\n";
            echo "---------------------------------\n";
            // VULNERABLE CODE: Direct concatenation of user input into shell_exec
            // This allows command injection via characters like ; | && $()
            $cmd = shell_exec("ping -c 3 " . $target);
            echo htmlspecialchars($cmd);
            echo '</div>';
        }
        ?>
        
        <div class="footer">
            &copy; 2024 Enterprise IT Services. authorized use only.
        </div>
    </div>
</body>
</html>
