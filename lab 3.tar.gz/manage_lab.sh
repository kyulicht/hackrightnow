#!/bin/bash

IMAGE_NAME="oscp_rce_lab"
CONTAINER_NAME="oscp_rce_container"
PORT=8085

function build_lab {
    echo "Building Docker image..."
    docker build -t $IMAGE_NAME .
}

function start_lab {
    echo "Starting lab on port $PORT..."
    # Check if container exists and remove it
    if [ "$(docker ps -aq -f name=$CONTAINER_NAME)" ]; then
        docker rm -f $CONTAINER_NAME
    fi
    
    docker run -d -p $PORT:80 --name $CONTAINER_NAME $IMAGE_NAME
    echo "Lab started! Access it at http://localhost:$PORT"
}

function stop_lab {
    echo "Stopping lab..."
    docker stop $CONTAINER_NAME
    docker rm $CONTAINER_NAME
    echo "Lab stopped and removed."
}

if [ "$1" == "build" ]; then
    build_lab
elif [ "$1" == "start" ]; then
    start_lab
elif [ "$1" == "stop" ]; then
    stop_lab
elif [ "$1" == "restart" ]; then
    stop_lab
    start_lab
else
    # Default behavior: build and start if no arguments or 'all'
    echo "Usage: ./manage_lab.sh [build|start|stop|restart]"
    echo "Defaulting to full setup (Build + Start)..."
    build_lab
    start_lab
fi
