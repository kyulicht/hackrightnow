<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch all users for "Admin View" (Intentionally Vulnerable Info Disclosure)
$users = [];
$result = $conn->query("SELECT * FROM users");
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Apex Cleaning</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav>
        <div class="logo">
            <i class="fas fa-sparkles"></i> APEX <span style="font-size: 0.8rem; margin-left: 10px; opacity: 0.7;">INTERNAL</span>
        </div>
        <div class="nav-links">
            <span>Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
            <a href="logout.php" class="btn-primary" style="padding: 0.5rem 1rem; font-size: 0.9rem;">Logout</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <div class="dashboard-header">
            <h1>System Overview</h1>
            <button class="btn-primary"><i class="fas fa-plus"></i> New Task</button>
        </div>

        <div style="background: white; padding: 2rem; border-radius: 15px; margin-bottom: 2rem; box-shadow: 0 5px 20px rgba(0,0,0,0.05);">
            <h3><i class="fas fa-users-cog"></i> User Management (Debug Mode)</h3>
            <p style="margin-bottom: 1rem; color: #666;">WARNING: Passwords are hashed. Contact sysadmin for resets.</p>
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Password Hash (MD5)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><span style="background: #e6f3ff; color: var(--primary); padding: 2px 8px; border-radius: 4px; font-size: 0.85rem;"><?php echo htmlspecialchars($user['role']); ?></span></td>
                        <td style="font-family: monospace; color: #e74c3c;"><?php echo $user['password_hash']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
