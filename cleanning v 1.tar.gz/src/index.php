<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apex Cleaning Solutions | Professional Commercial Cleaning</title>
    <link rel="stylesheet" href="assets/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav>
        <div class="logo">
            <i class="fas fa-sparkles"></i> APEX
        </div>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="#services">Services</a>
            <a href="#about">About</a>
            <a href="login.php" class="btn-primary">Employee Login</a>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1>Excellence in Every Detail</h1>
            <p>Premium commercial cleaning services tailored to your business needs. Experience the Apex standard of purity.</p>
            <a href="#contact" class="btn-primary">Get a Quote</a>
        </div>
    </section>

    <section class="features" id="services">
        <div class="feature-card">
            <i class="fas fa-building feature-icon"></i>
            <h3>Office Cleaning</h3>
            <p>Maintain a pristine workplace environment that enhances productivity and impresses clients.</p>
        </div>
        <div class="feature-card">
            <i class="fas fa-pump-medical feature-icon"></i>
            <h3>Sanitization</h3>
            <p>Hospital-grade disinfection services using eco-friendly, certified cleaning solutions.</p>
        </div>
        <div class="feature-card">
            <i class="fas fa-clock feature-icon"></i>
            <h3>24/7 Service</h3>
            <p>Flexible scheduling options to ensure your operations run smoothly without interruption.</p>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 Apex Cleaning Solutions. All rights reserved.</p>
    </footer>
</body>
</html>
