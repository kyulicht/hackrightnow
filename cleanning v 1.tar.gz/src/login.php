<?php
session_start();
require_once 'db_connect.php';

$ip = $_SERVER['REMOTE_ADDR'];
$lockout_file = "/tmp/login_attempts_" . md5($ip) . ".json";
$max_attempts = 300;
$lockout_time = 35; // seconds

// Initialize or read tracking data
if (file_exists($lockout_file)) {
    $data = json_decode(file_get_contents($lockout_file), true);
} else {
    $data = ['attempts' => 0, 'first_attempt' => time(), 'locked_until' => 0];
}

// Check if locked out
if (time() < $data['locked_until']) {
    $remaining = $data['locked_until'] - time();
    $error = "Too many failed attempts. Please wait $remaining seconds.";
} else {
    // Reset if lockout expired or time window passed (optional, strictly following the 300 attempts rule usually resets after success or timeout, here we just check lockout)
    if ($data['locked_until'] > 0 && time() >= $data['locked_until']) {
        $data = ['attempts' => 0, 'first_attempt' => time(), 'locked_until' => 0];
    }
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST['username'];
        $password = $_POST['password']; // In real app, verify hash. Here we check MD5 match against DB.

        $data['attempts']++;
        
        // Check if limit reached
        if ($data['attempts'] >= $max_attempts) {
            $data['locked_until'] = time() + $lockout_time;
            file_put_contents($lockout_file, json_encode($data));
             $error = "Maximum attempts reached. Locked for $lockout_time seconds.";
        } else {
            // Update attempts
            file_put_contents($lockout_file, json_encode($data));

            // DB Check
            $stmt = $conn->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($user = $result->fetch_assoc()) {
                if (md5($password) === $user['password_hash']) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    
                    // Reset attempts on success
                    unlink($lockout_file);
                    
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $error = "Invalid credentials.";
                }
            } else {
                $error = "Invalid credentials.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Login | Apex Cleaning</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <h2>Employee Portal</h2>
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn-primary" style="width: 100%">Sign In</button>
            </form>
            <p style="margin-top: 1rem;"><a href="index.php" style="color: var(--primary);">Back to Home</a></p>
        </div>
    </div>
</body>
</html>
