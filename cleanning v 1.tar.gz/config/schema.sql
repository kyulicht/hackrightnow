CREATE DATABASE IF NOT EXISTS cleaning_db;
USE cleaning_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(32) NOT NULL,
    role ENUM('admin', 'employee') DEFAULT 'employee'
);

-- Passwords:
-- admin:admin123 (0192023a7bbd73250516f069df18b500)
-- developer:iloveyou (2e99bf4e42962410038bc6fa4cfb4464) -> in rockyou.txt

INSERT INTO users (username, password_hash, role) VALUES 
('admin', '0192023a7bbd73250516f069df18b500', 'admin'),
('developer', '2e99bf4e42962410038bc6fa4cfb4464', 'employee');

GRANT ALL PRIVILEGES ON cleaning_db.* TO 'app_user'@'localhost' IDENTIFIED BY 'secure_pass_123';
FLUSH PRIVILEGES;
