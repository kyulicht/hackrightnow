#!/bin/bash

IMAGE_NAME="cleaning-lab-rce"
CONTAINER_NAME="cleaning-lab-container"
PORT_HTTP=8080
PORT_SSH=2222

cd "$(dirname "$0")"

function b {
    echo "Building Docker image..."
    docker build -t $IMAGE_NAME .
}

function s {
    echo "Starting Lab..."
    # Check if running
    if [ "$(docker ps -q -f name=$CONTAINER_NAME)" ]; then
        echo "Container is already running."
    else
        # Remove if exists but stopped
        docker rm $CONTAINER_NAME 2>/dev/null
        docker run -d -p $PORT_HTTP:80 -p $PORT_SSH:22 --name $CONTAINER_NAME $IMAGE_NAME
        echo "Lab started!"
        echo "Web: http://localhost:$PORT_HTTP"
        echo "SSH: ssh developer@localhost -p $PORT_SSH"
    fi
}

function st {
    echo "Stopping Lab..."
    docker stop $CONTAINER_NAME
}

function c {
    echo "removing container..."
    docker rm -f $CONTAINER_NAME
    echo "removing image..."
    docker rmi $IMAGE_NAME
}

case "$1" in
    build)
        b
        ;;
    start)
        s
        ;;
    stop)
        st
        ;;
    clean)
        c
        ;;
    *)
        echo "Usage: $0 {build|start|stop|clean}"
        exit 1
esac
