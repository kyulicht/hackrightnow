#!/bin/bash

# Start MariaDB
service mariadb start

# Initialize Database
echo "Initializing database..."
# Wait for MariaDB to be ready
sleep 5
mysql < /tmp/schema.sql
echo "Database initialized."

# Start SSH
service ssh start

# Start Apache in foreground
echo "Starting Apache..."
apachectl -D FOREGROUND
