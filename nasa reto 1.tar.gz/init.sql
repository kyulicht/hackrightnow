CREATE DATABASE IF NOT EXISTS nasa_security;
USE nasa_security;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'personnel'
);

CREATE TABLE IF NOT EXISTS top_secret (
    id INT AUTO_INCREMENT PRIMARY KEY,
    secret_data VARCHAR(255)
);

-- Insert a standard user and an admin
INSERT INTO users (username, password, role) VALUES ('guest', 'guest', 'personnel');
INSERT INTO users (username, password, role) VALUES ('admin', 's3cr3t_p4ssw0rd_nasa_2050', 'admin');

-- The Flag
INSERT INTO top_secret (secret_data) VALUES ('FLAG{HACKRIGHTNOW11sd21F654f5eF45E4f65e4fw64FEF}');

-- Grant permissions (safe practice for labs to ensure connectivity)
GRANT ALL PRIVILEGES ON nasa_security.* TO 'nasa_user'@'%';
FLUSH PRIVILEGES;
