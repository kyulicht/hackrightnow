#!/bin/bash

# NASA SQLi Lab Management Script
# Uses pure Docker commands for maximum portability

FUNCTION=$1
NETWORK_NAME="nasa_net"
DB_CONTAINER="nasa_sqli_db"
WEB_CONTAINER="nasa_sqli_web"
DB_IMAGE="mysql:5.7"
WEB_IMAGE="nasa_sqli_web_img"

check_docker() {
    if ! command -v docker &> /dev/null; then
        echo "Error: Docker is not installed."
        exit 1
    fi
    # Check permissions
    if ! docker ps &> /dev/null; then
        echo "Error: Permission denied. Try running this script with sudo:"
        echo "Example: sudo ./manage_lab.sh start"
        exit 1
    fi
}

cleanup() {
    echo "[*] Cleaning up existing containers..."
    docker stop $WEB_CONTAINER $DB_CONTAINER 2>/dev/null
    docker rm $WEB_CONTAINER $DB_CONTAINER 2>/dev/null
    docker network rm $NETWORK_NAME 2>/dev/null
}

case $FUNCTION in
    start)
        check_docker
        cleanup
        
        echo "[*] Creating network..."
        docker network create $NETWORK_NAME

        echo "[*] Starting Database..."
        docker run -d \
            --name $DB_CONTAINER \
            --network $NETWORK_NAME \
            -e MYSQL_ROOT_PASSWORD=rootpassword \
            -e MYSQL_DATABASE=nasa_security \
            -e MYSQL_USER=nasa_user \
            -e MYSQL_PASSWORD=nasa_pass \
            -v $(pwd)/init.sql:/docker-entrypoint-initdb.d/init.sql \
            $DB_IMAGE

        echo "[*] Building Web App..."
        docker build -t $WEB_IMAGE .

        echo "[*] Starting Web App..."
        # Wait for DB to fully initialize (MySQL can take time on first run)
        echo "[*] Waiting 15s for Database initialization..."
        sleep 15
        docker run -d \
            --name $WEB_CONTAINER \
            --network $NETWORK_NAME \
            -p 8080:80 \
            $WEB_IMAGE

        echo "[+] Lab is running!"
        echo "[+] Access the portal at: http://localhost:8080"
        ;;
    stop)
        echo "[*] Stopping lab..."
        docker stop $WEB_CONTAINER $DB_CONTAINER
        ;;
    logs)
        docker logs -f $WEB_CONTAINER
        ;;
    clean)
        cleanup
        echo "[-] Cleaned."
        ;;
    *)
        echo "Usage: ./manage_lab.sh {start|stop|logs|clean}"
        exit 1
        ;;
esac
