<?php
$servername = "nasa_sqli_db";
$username = "nasa_user";
$password = "nasa_pass";
$dbname = "nasa_security";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo "<div style='color: white; text-align: center; padding: 20px; font-family: monospace;'>";
    echo "<h1>SYSTEM ERROR</h1>";
    echo "<p>Connection to Secure Database failed.</p>";
    echo "<p>Status: " . $conn->connect_error . "</p>";
    echo "<p><em>Admin Note: If this is the first boot, the database system may still be initializing. Please refresh page in 10-20 seconds.</em></p>";
    echo "</div>";
    die();
}

$message = "";
$flag = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username']; // VULNERABLE: No sanitization
    $pass = $_POST['password'];

    // VULNERABLE QUERY
    $sql = "SELECT * FROM users WHERE username = '$user' AND password = '$pass'";
    
    // Debugging hint (optional, makes lab easier)
    // echo "<!-- DEBUG: $sql -->";

    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $message = "<div class='success'>ACCESS GRANTED: Welcome, " . htmlspecialchars($row['username']) . "</div>";
        
        // If admin, show flag
        if ($row['role'] === 'admin') {
            $flag_query = "SELECT secret_data FROM top_secret LIMIT 1";
            $flag_result = $conn->query($flag_query);
            if ($flag_result->num_rows > 0) {
                $flag_row = $flag_result->fetch_assoc();
                $flag = "<div class='success'>TOP SECRET DATA: " . $flag_row['secret_data'] . "</div>";
            }
        }
    } else {
        $message = "<div class='alert'>ACCESS DENIED: Invalid credentials. IP Logged.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NASA - Internal Security Gateway</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <!-- Minimal NASA worm logo placeholder or SVG could go here -->
        <h1>NASA SECURITY GATEWAY</h1>
        <p>Restricted Access. Authorized Personnel Only.</p>
        
        <form method="POST" class="login-form">
            <input type="text" name="username" placeholder="Agent ID / Username" required>
            <input type="password" name="password" placeholder="Access Code" required>
            <button type="submit">AUTHENTICATE</button>
        </form>

        <?php echo $message; ?>
        <?php echo $flag; ?>
    </div>
</body>
</html>
