<?php
// Define the file to store messages
$file = 'messages.txt';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['message'])) {
    $message = $_POST['message'];
    // VULNERABILITY: Storing input directly without sanitization
    // We append the message and a timestamp to the file
    $entry = date('Y-m-d H:i:s') . " - " . $message . PHP_EOL;
    file_put_contents($file, $entry, FILE_APPEND);
}

// Read messages
$messages = [];
if (file_exists($file)) {
    $messages = file($file, FILE_IGNORE_NEW_LINES);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NASA Mission Log - SECURE COMMS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="https://upload.wikimedia.org/wikipedia/commons/e/e5/NASA_logo.svg" alt="NASA Logo" width="100">
            </div>
            <h1>NASA Mission Log</h1>
            <p>Authorized Personnel Only. Leave your status report.</p>
        </header>

        <main>
            <section class="log-entry">
                <h2>Submit Log Entry</h2>
                <form method="POST" action="">
                    <textarea name="message" placeholder="Enter your mission status report..." rows="4" required></textarea>
                    <button type="submit">Transmit to Earth</button>
                </form>
            </section>

            <section class="logs">
                <h2>Recent Transmissions</h2>
                <div class="log-list">
                    <?php if (!empty($messages)): ?>
                        <?php foreach (array_reverse($messages) as $msg): ?>
                            <div class="log-item">
                                <!-- VULNERABILITY: Outputting content directly without escaping -->
                                <?php echo $msg; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No transmissions received.</p>
                    <?php endif; ?>
                </div>
            </section>
        </main>
        
        <footer>
            <p>&copy; <?php echo date('Y'); ?> NASA - National Aeronautics and Space Administration</p>
            <p class="warning">WARNING: This system is monitored. Unsanitized inputs detected in sector 7G.</p>
        </footer>
    </div>
</body>
</html>
