#!/bin/bash

# Configuration
IMAGE_NAME="nasa-xss-lab"
CONTAINER_NAME="nasa_xss_container"
PORT="8080"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

function build {
    echo -e "${GREEN}Building Docker image related to NASA...${NC}"
    docker build -t $IMAGE_NAME .
}

function start {
    echo -e "${GREEN}Deploying NASA Mission Control Interface on port $PORT...${NC}"
    # Check if container exists and remove it if so
    if [ "$(docker ps -aq -f name=$CONTAINER_NAME)" ]; then
        echo "Removing existing container..."
        docker rm -f $CONTAINER_NAME
    fi
    docker run -d -p $PORT:80 --name $CONTAINER_NAME $IMAGE_NAME
    echo -e "${GREEN}Lab is live at http://localhost:$PORT${NC}"
    echo -e "${GREEN}Access the mission log to begin testing.${NC}"
}

function stop {
    echo -e "${RED}Aborting mission... Stopping container...${NC}"
    docker stop $CONTAINER_NAME
    docker rm $CONTAINER_NAME
    echo -e "${RED}Mission aborted.${NC}"
}

function clean {
    echo -e "${RED}Declassifying attributes... Removing image...${NC}"
    stop
    docker rmi $IMAGE_NAME
    echo -e "${RED}Assets neutralized.${NC}"
}

function help {
    echo "Usage: $0 {build|start|stop|clean}"
}

# Argument handling
if [ $# -eq 0 ]; then
    help
    exit 1
fi

case "$1" in
    build)
        build
        ;;
    start)
        start
        ;;
    stop)
        stop
        ;;
    clean)
        clean
        ;;
    *)
        help
        exit 1
esac
